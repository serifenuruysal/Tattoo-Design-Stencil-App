
  # Tattoo Design Stencil App

  This is a code bundle for Tattoo Design Stencil App. The original project is available at https://www.figma.com/design/OUwBiIwftQy2XUqa8iolnZ/Tattoo-Design-Stencil-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  