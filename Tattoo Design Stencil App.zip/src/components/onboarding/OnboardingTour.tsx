import React, { useState, useEffect } from 'react';
import { Button } from '../ui/button';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';
import { X, ArrowRight, ArrowLeft, CheckCircle, Upload, Settings, Download, Palette, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  targetElement?: string;
  position: 'center' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface OnboardingTourProps {
  isVisible: boolean;
  onComplete: () => void;
  onSkip: () => void;
}

export function OnboardingTour({ isVisible, onComplete, onSkip }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const steps: OnboardingStep[] = [
    {
      id: 'welcome',
      title: 'Welcome to Tattoo Stencil Generator!',
      description: 'Transform any design into professional tattoo stencils in seconds. Let\'s take a quick tour to get you started.',
      icon: <Palette className="size-6 text-primary" />,
      position: 'center'
    },
    {
      id: 'upload',
      title: 'Upload Your Design',
      description: 'Start by uploading any image - sketches, photos, or digital art. Drag & drop or click to select.',
      icon: <Upload className="size-6 text-blue-500" />,
      position: 'center',
      targetElement: 'upload-area'
    },
    {
      id: 'processing-modes',
      title: 'Choose Your Processing Mode',
      description: 'Select from three powerful modes: Solid Stencil for bold designs, Line Sketch for detailed work, or get both Black & White + Line versions.',
      icon: <Sparkles className="size-6 text-purple-500" />,
      position: 'center'
    },
    {
      id: 'settings',
      title: 'Fine-tune Your Results',
      description: 'Adjust threshold, contrast, and line thickness to perfect your stencil. Changes are applied in real-time!',
      icon: <Settings className="size-6 text-green-500" />,
      position: 'center',
      targetElement: 'settings-panel'
    },
    {
      id: 'preview',
      title: 'Preview & Download',
      description: 'See your results instantly with side-by-side comparison. Download individual stencils when you\'re satisfied.',
      icon: <Download className="size-6 text-orange-500" />,
      position: 'center',
      targetElement: 'preview-area'
    },
    {
      id: 'complete',
      title: 'You\'re All Set!',
      description: 'Ready to create amazing stencils? Your designs will be processed with professional-quality algorithms for the best results.',
      icon: <CheckCircle className="size-6 text-green-500" />,
      position: 'center'
    }
  ];

  const nextStep = async () => {
    if (currentStep < steps.length - 1) {
      setIsAnimating(true);
      await new Promise(resolve => setTimeout(resolve, 150));
      setCurrentStep(currentStep + 1);
      setIsAnimating(false);
    } else {
      onComplete();
    }
  };

  const prevStep = async () => {
    if (currentStep > 0) {
      setIsAnimating(true);
      await new Promise(resolve => setTimeout(resolve, 150));
      setCurrentStep(currentStep - 1);
      setIsAnimating(false);
    }
  };

  const skipTour = () => {
    onSkip();
  };

  if (!isVisible) return null;

  const currentStepData = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  const isFirstStep = currentStep === 0;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: isAnimating ? 0 : 1, scale: isAnimating ? 0.9 : 1, y: isAnimating ? 20 : 0 }}
          exit={{ opacity: 0, scale: 0.9, y: -20 }}
          transition={{ duration: 0.2, ease: "easeInOut" }}
        >
          <Card className="w-full max-w-lg mx-auto p-6 relative">
            {/* Close Button */}
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-4 right-4 size-8 p-0"
              onClick={skipTour}
            >
              <X className="size-4" />
            </Button>

            {/* Progress Indicator */}
            <div className="flex items-center gap-2 mb-6">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 flex-1 rounded-full transition-colors duration-200 ${
                    index <= currentStep ? 'bg-primary' : 'bg-muted'
                  }`}
                />
              ))}
            </div>

            {/* Step Content */}
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="size-16 bg-primary/10 rounded-full flex items-center justify-center">
                  {currentStepData.icon}
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-xl font-semibold">{currentStepData.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {currentStepData.description}
                </p>
              </div>

              {/* Mode Cards for Processing Modes Step */}
              {currentStep === 2 && (
                <div className="grid grid-cols-1 gap-3 mt-6">
                  <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
                    <Badge variant="secondary">Solid</Badge>
                    <span className="text-sm text-left">Classic black & white stencil</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
                    <Badge variant="secondary">Line</Badge>
                    <span className="text-sm text-left">Edge-detected outlines only</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/30">
                    <Badge variant="secondary">Both</Badge>
                    <span className="text-sm text-left">Black & white + line sketch</span>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={prevStep}
                  disabled={isFirstStep}
                  className="gap-2"
                >
                  <ArrowLeft className="size-4" />
                  Back
                </Button>

                <div className="flex items-center gap-2">
                  {!isLastStep && (
                    <Button variant="ghost" onClick={skipTour}>
                      Skip Tour
                    </Button>
                  )}
                  
                  <Button onClick={nextStep} className="gap-2">
                    {isLastStep ? 'Get Started' : 'Next'}
                    {!isLastStep && <ArrowRight className="size-4" />}
                    {isLastStep && <CheckCircle className="size-4" />}
                  </Button>
                </div>
              </div>
            </div>

            {/* Step Counter */}
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
              <span className="text-xs text-muted-foreground">
                {currentStep + 1} of {steps.length}
              </span>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// Hook for managing onboarding state
export function useOnboarding() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState(false);

  useEffect(() => {
    // Check if user has seen onboarding before
    const hasSeenBefore = localStorage.getItem('tattoo-stencil-onboarding-seen');
    if (!hasSeenBefore) {
      setShowOnboarding(true);
    } else {
      setHasSeenOnboarding(true);
    }
  }, []);

  const completeOnboarding = () => {
    localStorage.setItem('tattoo-stencil-onboarding-seen', 'true');
    setShowOnboarding(false);
    setHasSeenOnboarding(true);
  };

  const skipOnboarding = () => {
    localStorage.setItem('tattoo-stencil-onboarding-seen', 'true');
    setShowOnboarding(false);
    setHasSeenOnboarding(true);
  };

  const restartOnboarding = () => {
    localStorage.removeItem('tattoo-stencil-onboarding-seen');
    setShowOnboarding(true);
    setHasSeenOnboarding(false);
  };

  return {
    showOnboarding,
    hasSeenOnboarding,
    completeOnboarding,
    skipOnboarding,
    restartOnboarding
  };
}